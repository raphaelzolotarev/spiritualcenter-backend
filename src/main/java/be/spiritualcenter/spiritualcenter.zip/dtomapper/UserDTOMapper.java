package be.spiritualcenter.dtomapper;

import be.spiritualcenter.domain.User;
import be.spiritualcenter.dto.UserDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Bean;
/*
 * @author Raphael Zolotarev
 * @version 1.0
 * @license Copyright (c) 2025 www.zolotarev.eu
 * @since 03/03/2025
 */
public class UserDTOMapper {
    public static UserDTO fromUser(User user){
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(user, userDTO);
        return userDTO;
    }
    public static User toUser(UserDTO userDTO){
        User user = new User();
        BeanUtils.copyProperties(userDTO, user);
        return user;
    }
}
