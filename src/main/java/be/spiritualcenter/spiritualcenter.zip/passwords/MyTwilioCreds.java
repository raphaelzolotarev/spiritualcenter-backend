package be.spiritualcenter.passwords;
/*
 * @author Raphael Zolotarev
 * @version 1.0
 * @license Copyright (c) 2025 www.zolotarev.eu
 * @since 03/03/2025
 */

public class MyTwilioCreds {
    public final static String FROM_NUMBER = "+14254704386";
    public static final String SID_KEY = "AC29372d0575aaa82553c23443a48af33a";
    public static final String TOKEN_KEY = "0b392b648593e68afeb0189ff52168b5";
}
